
Pluralsight  
# WPF MVVM in Depth
by Brian Noyles  

2. MVVM Pattern Fundamentals   
View ViewModel Construction  