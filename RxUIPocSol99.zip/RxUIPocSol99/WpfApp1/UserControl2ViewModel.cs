﻿using ReactiveUI;

namespace WpfApp1
{
    public class UserControl2ViewModel : ReactiveObject
    {
        public string MyPropertyOnVM2 { get; set; }
    }
}